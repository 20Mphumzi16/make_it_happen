import { FormEvent, useCallback, useEffect, useState } from "react";

const API_URL = "http://localhost:8080/api/tasks";

type ApiTask = {
  id?: number | string;
  ID?: number | string;
  title?: string;
  Title?: string;
  status?: boolean;
  Status?: boolean;
  completed?: boolean;
  completionStatus?: boolean;
};

type Task = {
  id: number | string;
  title: string;
  status: boolean;
};

function normalizeTask(task: ApiTask): Task {
  return {
    id: task.id ?? task.ID ?? "",
    title: task.title ?? task.Title ?? "Untitled task",
    status:
      task.status ??
      task.Status ??
      task.completed ??
      task.completionStatus ??
      false,
  };
}

async function getErrorMessage(response: Response) {
  try {
    const body = await response.json();
    return body.message || body.error || `Request failed (${response.status})`;
  } catch {
    return `Request failed (${response.status})`;
  }
}

export default function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [title, setTitle] = useState("");
  const [lookupId, setLookupId] = useState("");
  const [editingId, setEditingId] = useState<Task["id"] | null>(null);
  const [editingTitle, setEditingTitle] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState("");

  const fetchTasks = useCallback(async () => {
    setIsLoading(true);
    setError("");

    try {
      const response = await fetch(API_URL);
      if (!response.ok) throw new Error(await getErrorMessage(response));

      const data = await response.json();
      const taskList = Array.isArray(data) ? data : data.tasks || [];
      setTasks(taskList.map(normalizeTask));
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Unable to load tasks.",
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchTasks();
  }, [fetchTasks]);

  async function createTask(event: FormEvent) {
    event.preventDefault();
    const trimmedTitle = title.trim();
    if (!trimmedTitle) return;

    setIsSaving(true);
    setError("");

    try {
      const response = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: trimmedTitle, status: false }),
      });
      if (!response.ok) throw new Error(await getErrorMessage(response));

      setTitle("");
      await fetchTasks();
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Unable to create the task.",
      );
    } finally {
      setIsSaving(false);
    }
  }

  async function findTask(event: FormEvent) {
    event.preventDefault();
    const id = lookupId.trim();
    if (!id) {
      await fetchTasks();
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      const response = await fetch(`${API_URL}/${encodeURIComponent(id)}`);
      if (!response.ok) throw new Error(await getErrorMessage(response));

      const task = normalizeTask(await response.json());
      setTasks([task]);
    } catch (requestError) {
      setTasks([]);
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Unable to find that task.",
      );
    } finally {
      setIsLoading(false);
    }
  }

  async function updateTask(task: Task, changes: Partial<Task>) {
    const updatedTask = { ...task, ...changes };
    setError("");

    try {
      const response = await fetch(
        `${API_URL}/${encodeURIComponent(String(task.id))}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            id: updatedTask.id,
            status: updatedTask.status,
            title: updatedTask.title,
          }),
        },
      );
      if (!response.ok) throw new Error(await getErrorMessage(response));

      setTasks((current) =>
        current.map((item) =>
          item.id === task.id ? normalizeTask(updatedTask) : item,
        ),
      );
      setEditingId(null);
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Unable to update the task.",
      );
    }
  }

  async function deleteTask(task: Task) {
    setError("");

    try {
      const response = await fetch(
        `${API_URL}/${encodeURIComponent(String(task.id))}`,
        { method: "DELETE" },
      );
      if (!response.ok) throw new Error(await getErrorMessage(response));

      setTasks((current) => current.filter((item) => item.id !== task.id));
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "Unable to delete the task.",
      );
    }
  }

  const completedCount = tasks.filter((task) => task.status).length;

  return (
    <main className="min-h-screen bg-[#f5f5f2] px-4 py-8 text-[#20201d] sm:px-6 sm:py-12">
      <div className="mx-auto w-full max-w-3xl">
        <header className="mb-8 sm:mb-10">
          <div className="mb-4 flex items-center gap-3">
            <span className="h-px w-8 bg-[#ff5c35]" />
            <span className="text-xs font-bold tracking-[0.2em] text-[#ff5c35] uppercase">
              Daily focus
            </span>
          </div>
          <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <h1 className="text-4xl font-semibold tracking-[-0.04em] sm:text-5xl">
                Make it happen.
              </h1>
              <p className="mt-3 max-w-lg text-base leading-7 text-[#6e6d66]">
                A simple place to capture what matters and move through your
                day with clarity.
              </p>
            </div>
            <div className="shrink-0 text-left sm:text-right">
              <p className="text-2xl font-semibold">
                {completedCount}
                <span className="text-[#b4b2aa]">/{tasks.length}</span>
              </p>
              <p className="text-xs font-medium tracking-wide text-[#77766f] uppercase">
                Completed
              </p>
            </div>
          </div>
        </header>

        <section className="mb-5 rounded-2xl border border-[#deddd7] bg-white p-3 shadow-[0_10px_30px_rgba(40,40,30,0.04)] sm:p-4">
          <form className="flex gap-2" onSubmit={createTask}>
            <label className="sr-only" htmlFor="new-task">
              New task title
            </label>
            <input
              id="new-task"
              className="min-w-0 flex-1 rounded-xl bg-[#f5f5f2] px-4 py-3 text-sm outline-none transition placeholder:text-[#9b9a94] focus:ring-2 focus:ring-[#ff5c35]/30"
              onChange={(event) => setTitle(event.target.value)}
              placeholder="What needs to be done?"
              value={title}
            />
            <button
              className="rounded-xl bg-[#20201d] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#ff5c35] disabled:cursor-not-allowed disabled:opacity-50"
              disabled={!title.trim() || isSaving}
              type="submit"
            >
              {isSaving ? "Adding…" : "Add task"}
            </button>
          </form>
        </section>

        <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
          <h2 className="text-sm font-semibold tracking-wide uppercase">
            Your tasks
          </h2>
          <form className="flex gap-2" onSubmit={findTask}>
            <label className="sr-only" htmlFor="lookup-id">
              Find task by ID
            </label>
            <input
              id="lookup-id"
              className="w-full rounded-lg border border-[#d5d4ce] bg-transparent px-3 py-2 text-sm outline-none focus:border-[#ff5c35] sm:w-40"
              onChange={(event) => setLookupId(event.target.value)}
              placeholder="Find by ID"
              value={lookupId}
            />
            <button
              className="rounded-lg border border-[#20201d] px-4 py-2 text-sm font-semibold transition hover:bg-[#20201d] hover:text-white"
              type="submit"
            >
              Find
            </button>
            {lookupId && (
              <button
                className="px-2 text-sm text-[#6e6d66] underline-offset-4 hover:underline"
                onClick={() => {
                  setLookupId("");
                  void fetchTasks();
                }}
                type="button"
              >
                All
              </button>
            )}
          </form>
        </div>

        {error && (
          <div
            className="mb-4 rounded-xl border border-[#f3b7a8] bg-[#fff2ee] px-4 py-3 text-sm text-[#a63217]"
            role="alert"
          >
            {error}
          </div>
        )}

        <section className="overflow-hidden rounded-2xl border border-[#deddd7] bg-white shadow-[0_10px_30px_rgba(40,40,30,0.04)]">
          {isLoading ? (
            <div className="p-10 text-center text-sm text-[#77766f]">
              Loading tasks…
            </div>
          ) : tasks.length === 0 ? (
            <div className="p-10 text-center">
              <div className="mx-auto mb-4 flex h-11 w-11 items-center justify-center rounded-full border border-dashed border-[#aaa89f]">
                <span className="h-2 w-2 rounded-full bg-[#ff5c35]" />
              </div>
              <p className="font-semibold">Nothing on your list</p>
              <p className="mt-1 text-sm text-[#77766f]">
                Add a task above to get started.
              </p>
            </div>
          ) : (
            <ul>
              {tasks.map((task, index) => (
                <li
                  className={`group flex items-center gap-3 px-4 py-4 sm:px-5 ${
                    index !== tasks.length - 1
                      ? "border-b border-[#ecebe6]"
                      : ""
                  }`}
                  key={task.id}
                >
                  <button
                    aria-label={
                      task.status ? "Mark as incomplete" : "Mark as complete"
                    }
                    className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border transition ${
                      task.status
                        ? "border-[#ff5c35] bg-[#ff5c35]"
                        : "border-[#b9b7ae] hover:border-[#ff5c35]"
                    }`}
                    onClick={() =>
                      void updateTask(task, { status: !task.status })
                    }
                    type="button"
                  >
                    {task.status && (
                      <span className="h-2 w-3 -translate-y-px rotate-[-45deg] border-b-2 border-l-2 border-white" />
                    )}
                  </button>

                  <div className="min-w-0 flex-1">
                    {editingId === task.id ? (
                      <form
                        className="flex gap-2"
                        onSubmit={(event) => {
                          event.preventDefault();
                          const nextTitle = editingTitle.trim();
                          if (nextTitle) void updateTask(task, { title: nextTitle });
                        }}
                      >
                        <input
                          autoFocus
                          className="min-w-0 flex-1 rounded-lg border border-[#ff5c35] px-3 py-1.5 text-sm outline-none ring-2 ring-[#ff5c35]/15"
                          onChange={(event) =>
                            setEditingTitle(event.target.value)
                          }
                          value={editingTitle}
                        />
                        <button
                          className="text-sm font-semibold text-[#ff5c35]"
                          type="submit"
                        >
                          Save
                        </button>
                      </form>
                    ) : (
                      <>
                        <p
                          className={`truncate text-sm font-medium ${
                            task.status
                              ? "text-[#9b9a94] line-through"
                              : "text-[#282824]"
                          }`}
                        >
                          {task.title}
                        </p>
                        <p className="mt-0.5 text-xs text-[#aaa89f]">
                          Task #{task.id}
                        </p>
                      </>
                    )}
                  </div>

                  {editingId !== task.id && (
                    <div className="flex shrink-0 gap-1 opacity-70 transition group-hover:opacity-100">
                      <button
                        className="rounded-lg px-3 py-2 text-xs font-semibold text-[#65645e] transition hover:bg-[#f1f0eb] hover:text-[#20201d]"
                        onClick={() => {
                          setEditingId(task.id);
                          setEditingTitle(task.title);
                        }}
                        type="button"
                      >
                        Edit
                      </button>
                      <button
                        className="rounded-lg px-3 py-2 text-xs font-semibold text-[#a63217] transition hover:bg-[#fff0ec]"
                        onClick={() => void deleteTask(task)}
                        type="button"
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>

        <p className="mt-5 text-center text-xs text-[#9b9a94]">
          Synced with {API_URL}
        </p>
      </div>
    </main>
  );
}
